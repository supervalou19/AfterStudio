import Component from "./component";
import config from "./config.json";

export default {
  component: Component,
  config,
};
