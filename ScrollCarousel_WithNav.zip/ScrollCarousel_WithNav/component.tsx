import React from "react";

type Props = {
  items: { image: string; text: string }[];
};

export default function Component({ items }: Props) {
  return (
    <div style={{ position: "relative" }}>
      <button className="scroll-left">&#8249;</button>
      <div className="scroll-container">
        {items.map((item, index) => (
          <div className="card-item" key={index}>
            <img className="card-img" src={item.image} alt={item.text} />
            <div className="card-text">{item.text}</div>
          </div>
        ))}
      </div>
      <button className="scroll-right">&#8250;</button>
    </div>
  );
}
